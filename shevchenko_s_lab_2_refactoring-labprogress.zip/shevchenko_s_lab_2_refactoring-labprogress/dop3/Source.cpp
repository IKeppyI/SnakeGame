#include <iostream>

 
    class IShape {
    public:
        virtual void draw() = 0; 
        virtual ~IShape() = default; 
    };


    class Shape : public IShape {
    public:
        void draw() override {
            std::cout << "Drawing a shape!" << std::endl;
        }
    };


    class Circle : public Shape {
    public:
        void draw() override {
            std::cout << "Drawing a circle!" << std::endl;
        }
    };

    class Square : public Shape {
    public:
        void draw() override {
            Shape::draw(); 
        }
    };

    void drawShape(IShape * shape) {
        shape->draw();
    }

    int main() {
        Shape* shape1 = new Circle(); 
        Shape* shape2 = new Square(); 

        shape1->draw();
        shape2->draw(); 
 
  
        delete shape1;
        delete shape2;

        return 0;
    }

